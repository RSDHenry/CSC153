﻿/**
* 14 FEB 2018
* CSC 153
* Rashad Henry
* A program that builds a sentence from button clicks.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Sentence_Builder
{
    public partial class Form1 : Form
    {
        // Constant fields
        const String CAPITAL_A = "A ";
        const String LOWER_CASE_A = "a ";
        const String CAPITAL_AN = "An ";
        const String LOWER_CASE_AN = "an ";
        const String CAPITAL_THE = "The ";
        const String LOWER_CASE_THE = "the ";
        const String MAN = "man ";
        const String WOMAN = "woman ";
        const String DOG = "dog ";
        const String CAT = "cat ";
        const String CAR = "car ";
        const String BICYCLE = "bicycle ";
        const String BEAUTIFUL = "beautiful ";
        const String BIG = "big ";
        const String SMALL = "small ";
        const String STRANGE = "strange ";
        const String LOOKEDAT = "looked at ";
        const String RODE = "rode ";
        const String SPOKETO = "spoke to ";
        const String LAUGHEDAT = "laughed at ";
        const String DROVE = "drove ";
        const String SPACE = " ";
        const String PERIOD = ".";
        const String EXCLAMATION = "!";

        // Declare a private field to hold a blank string.
        private String sentence = " ";
        public Form1()
        {
            InitializeComponent();
        }

        private void capitalAButton_Click(object sender, EventArgs e)
        {
            // Add the capital A letter to the sentence and display it to the label box.
            sentence += CAPITAL_A;
            displaySentenceLabel.Text = sentence;
        }

        private void lowerCaseAButton_Click(object sender, EventArgs e)
        {
            // Add the lower case A letter to the sentence and display it to the label box.
            sentence += LOWER_CASE_A;
            displaySentenceLabel.Text = sentence;
        }

        private void capitalAnButton_Click(object sender, EventArgs e)
        {
            // Add the capital An to the sentence and display it to the label box.
            sentence += CAPITAL_AN;
            displaySentenceLabel.Text = sentence;
        }

        private void lowerCaseAnButton_Click(object sender, EventArgs e)
        {
            // Add the lower case an to the sentence and display it to the label box.
            sentence += LOWER_CASE_AN;
            displaySentenceLabel.Text = sentence;
        }

        private void capitalTheButton_Click(object sender, EventArgs e)
        {
            // Add the capital The to the sentence and display it to the label box.
            sentence += CAPITAL_THE;
            displaySentenceLabel.Text = sentence;
        }

        private void lowerCaseTheButton_Click(object sender, EventArgs e)
        {
            // Add the lower case the to the sentence and display it to the label box.
            sentence += LOWER_CASE_THE;
            displaySentenceLabel.Text = sentence;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            // Add the word "man" to the sentence and display it to the label box.
            sentence += MAN;
            displaySentenceLabel.Text = sentence;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            // Add the word "woman" to the sentence and display it to the label box.
            sentence += WOMAN;
            displaySentenceLabel.Text = sentence;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            // Add the word " dog" to the sentence.
            sentence += DOG;
            displaySentenceLabel.Text = sentence;
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            // Add the wword "cat" to the sentence.
            sentence += CAT;
            displaySentenceLabel.Text = sentence;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            // Add the word "car" to the sentence.
            sentence += CAR;
            displaySentenceLabel.Text = sentence;
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            // Add the wrod "bicycle" to the sentence.
            sentence += BICYCLE;
            displaySentenceLabel.Text = sentence;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            // Add the word "beautiful" to the sentence.
            sentence += BEAUTIFUL;
            displaySentenceLabel.Text = sentence;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            // Add the word "big" to the sentence.
            sentence += BIG;
            displaySentenceLabel.Text = sentence;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            // Add the word "small" to the sentence.
            sentence += SMALL;
            displaySentenceLabel.Text = sentence;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            // Add the word "strange" to the sentence.
            sentence += STRANGE;
            displaySentenceLabel.Text = sentence;
        }

        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            // Add the phrase "looked at" to the sentence.
            sentence += LOOKEDAT;
            displaySentenceLabel.Text = sentence;
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            // Add the word "rode" to the sentence.
            sentence += RODE;
            displaySentenceLabel.Text = sentence;
        }

        private void spokeToButton_Click(object sender, EventArgs e)
        {
            // Add the phrase "spoke to" to the sentence.
            sentence += SPOKETO;
            displaySentenceLabel.Text = sentence;
        }

        private void laughedAtButton_Click(object sender, EventArgs e)
        {
            // Add the phrase "laughed at" to the sentence.
            sentence += LAUGHEDAT;
            displaySentenceLabel.Text = sentence;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            // Add the word "drove" to the sentence.
            sentence += DROVE;
            displaySentenceLabel.Text = sentence;
        }

        private void spaceBarButton_Click(object sender, EventArgs e)
        {
            // Add a blank space to the sentence.
            sentence += SPACE;
            displaySentenceLabel.Text = sentence;
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            // Add the period symbol to the sentence.
            sentence += PERIOD;
            displaySentenceLabel.Text = sentence;
        }

        private void exclamationPointButton_Click(object sender, EventArgs e)
        {
            // Add the exclamation point symbol to the sentence.
            sentence += EXCLAMATION;
            displaySentenceLabel.Text = sentence;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear all the text from the label.
            displaySentenceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}
