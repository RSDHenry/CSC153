﻿namespace Sentence_Builder
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.displaySentenceLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.capitalAButton = new System.Windows.Forms.Button();
            this.lowerCaseAButton = new System.Windows.Forms.Button();
            this.capitalAnButton = new System.Windows.Forms.Button();
            this.lowerCaseAnButton = new System.Windows.Forms.Button();
            this.capitalTheButton = new System.Windows.Forms.Button();
            this.lowerCaseTheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedAtButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeToButton = new System.Windows.Forms.Button();
            this.laughedAtButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceBarButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationPointButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // displaySentenceLabel
            // 
            this.displaySentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displaySentenceLabel.Location = new System.Drawing.Point(7, 220);
            this.displaySentenceLabel.Name = "displaySentenceLabel";
            this.displaySentenceLabel.Size = new System.Drawing.Size(706, 23);
            this.displaySentenceLabel.TabIndex = 0;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(260, 276);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 1;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(341, 276);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 2;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // capitalAButton
            // 
            this.capitalAButton.Location = new System.Drawing.Point(122, 39);
            this.capitalAButton.Name = "capitalAButton";
            this.capitalAButton.Size = new System.Drawing.Size(75, 23);
            this.capitalAButton.TabIndex = 3;
            this.capitalAButton.Text = "A";
            this.capitalAButton.UseVisualStyleBackColor = true;
            this.capitalAButton.Click += new System.EventHandler(this.capitalAButton_Click);
            // 
            // lowerCaseAButton
            // 
            this.lowerCaseAButton.Location = new System.Drawing.Point(203, 39);
            this.lowerCaseAButton.Name = "lowerCaseAButton";
            this.lowerCaseAButton.Size = new System.Drawing.Size(75, 23);
            this.lowerCaseAButton.TabIndex = 4;
            this.lowerCaseAButton.Text = "a";
            this.lowerCaseAButton.UseVisualStyleBackColor = true;
            this.lowerCaseAButton.Click += new System.EventHandler(this.lowerCaseAButton_Click);
            // 
            // capitalAnButton
            // 
            this.capitalAnButton.Location = new System.Drawing.Point(284, 39);
            this.capitalAnButton.Name = "capitalAnButton";
            this.capitalAnButton.Size = new System.Drawing.Size(75, 23);
            this.capitalAnButton.TabIndex = 5;
            this.capitalAnButton.Text = "An";
            this.capitalAnButton.UseVisualStyleBackColor = true;
            this.capitalAnButton.Click += new System.EventHandler(this.capitalAnButton_Click);
            // 
            // lowerCaseAnButton
            // 
            this.lowerCaseAnButton.Location = new System.Drawing.Point(365, 39);
            this.lowerCaseAnButton.Name = "lowerCaseAnButton";
            this.lowerCaseAnButton.Size = new System.Drawing.Size(75, 23);
            this.lowerCaseAnButton.TabIndex = 6;
            this.lowerCaseAnButton.Text = "an";
            this.lowerCaseAnButton.UseVisualStyleBackColor = true;
            this.lowerCaseAnButton.Click += new System.EventHandler(this.lowerCaseAnButton_Click);
            // 
            // capitalTheButton
            // 
            this.capitalTheButton.Location = new System.Drawing.Point(446, 39);
            this.capitalTheButton.Name = "capitalTheButton";
            this.capitalTheButton.Size = new System.Drawing.Size(75, 23);
            this.capitalTheButton.TabIndex = 7;
            this.capitalTheButton.Text = "The";
            this.capitalTheButton.UseVisualStyleBackColor = true;
            this.capitalTheButton.Click += new System.EventHandler(this.capitalTheButton_Click);
            // 
            // lowerCaseTheButton
            // 
            this.lowerCaseTheButton.Location = new System.Drawing.Point(527, 39);
            this.lowerCaseTheButton.Name = "lowerCaseTheButton";
            this.lowerCaseTheButton.Size = new System.Drawing.Size(75, 23);
            this.lowerCaseTheButton.TabIndex = 8;
            this.lowerCaseTheButton.Text = "the";
            this.lowerCaseTheButton.UseVisualStyleBackColor = true;
            this.lowerCaseTheButton.Click += new System.EventHandler(this.lowerCaseTheButton_Click);
            // 
            // manButton
            // 
            this.manButton.Location = new System.Drawing.Point(72, 68);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(75, 23);
            this.manButton.TabIndex = 9;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.Location = new System.Drawing.Point(160, 68);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(75, 23);
            this.womanButton.TabIndex = 10;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.Location = new System.Drawing.Point(241, 68);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(75, 23);
            this.dogButton.TabIndex = 11;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.Location = new System.Drawing.Point(326, 68);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(75, 23);
            this.catButton.TabIndex = 12;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.Location = new System.Drawing.Point(408, 68);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(75, 23);
            this.carButton.TabIndex = 13;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.Location = new System.Drawing.Point(489, 68);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(75, 23);
            this.bicycleButton.TabIndex = 14;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.Location = new System.Drawing.Point(203, 97);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(75, 23);
            this.beautifulButton.TabIndex = 15;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.Location = new System.Drawing.Point(284, 97);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(75, 23);
            this.bigButton.TabIndex = 16;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.Location = new System.Drawing.Point(365, 97);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(75, 23);
            this.smallButton.TabIndex = 17;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.Location = new System.Drawing.Point(446, 97);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(75, 23);
            this.strangeButton.TabIndex = 18;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedAtButton
            // 
            this.lookedAtButton.Location = new System.Drawing.Point(160, 126);
            this.lookedAtButton.Name = "lookedAtButton";
            this.lookedAtButton.Size = new System.Drawing.Size(75, 23);
            this.lookedAtButton.TabIndex = 19;
            this.lookedAtButton.Text = "looked at";
            this.lookedAtButton.UseVisualStyleBackColor = true;
            this.lookedAtButton.Click += new System.EventHandler(this.lookedAtButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.Location = new System.Drawing.Point(241, 126);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(75, 23);
            this.rodeButton.TabIndex = 20;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeToButton
            // 
            this.spokeToButton.Location = new System.Drawing.Point(322, 126);
            this.spokeToButton.Name = "spokeToButton";
            this.spokeToButton.Size = new System.Drawing.Size(75, 23);
            this.spokeToButton.TabIndex = 21;
            this.spokeToButton.Text = "spoke to";
            this.spokeToButton.UseVisualStyleBackColor = true;
            this.spokeToButton.Click += new System.EventHandler(this.spokeToButton_Click);
            // 
            // laughedAtButton
            // 
            this.laughedAtButton.Location = new System.Drawing.Point(403, 126);
            this.laughedAtButton.Name = "laughedAtButton";
            this.laughedAtButton.Size = new System.Drawing.Size(75, 23);
            this.laughedAtButton.TabIndex = 22;
            this.laughedAtButton.Text = "laughed at";
            this.laughedAtButton.UseVisualStyleBackColor = true;
            this.laughedAtButton.Click += new System.EventHandler(this.laughedAtButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.Location = new System.Drawing.Point(484, 126);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(75, 23);
            this.droveButton.TabIndex = 23;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceBarButton
            // 
            this.spaceBarButton.Location = new System.Drawing.Point(196, 155);
            this.spaceBarButton.Name = "spaceBarButton";
            this.spaceBarButton.Size = new System.Drawing.Size(75, 23);
            this.spaceBarButton.TabIndex = 24;
            this.spaceBarButton.Text = "(Space)";
            this.spaceBarButton.UseVisualStyleBackColor = true;
            this.spaceBarButton.Click += new System.EventHandler(this.spaceBarButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.Location = new System.Drawing.Point(305, 155);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(30, 23);
            this.periodButton.TabIndex = 25;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationPointButton
            // 
            this.exclamationPointButton.Location = new System.Drawing.Point(386, 155);
            this.exclamationPointButton.Name = "exclamationPointButton";
            this.exclamationPointButton.Size = new System.Drawing.Size(30, 23);
            this.exclamationPointButton.TabIndex = 26;
            this.exclamationPointButton.Text = "!";
            this.exclamationPointButton.UseVisualStyleBackColor = true;
            this.exclamationPointButton.Click += new System.EventHandler(this.exclamationPointButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(733, 365);
            this.Controls.Add(this.exclamationPointButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceBarButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedAtButton);
            this.Controls.Add(this.spokeToButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedAtButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.lowerCaseTheButton);
            this.Controls.Add(this.capitalTheButton);
            this.Controls.Add(this.lowerCaseAnButton);
            this.Controls.Add(this.capitalAnButton);
            this.Controls.Add(this.lowerCaseAButton);
            this.Controls.Add(this.capitalAButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displaySentenceLabel);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label displaySentenceLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button capitalAButton;
        private System.Windows.Forms.Button lowerCaseAButton;
        private System.Windows.Forms.Button capitalAnButton;
        private System.Windows.Forms.Button lowerCaseAnButton;
        private System.Windows.Forms.Button capitalTheButton;
        private System.Windows.Forms.Button lowerCaseTheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedAtButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeToButton;
        private System.Windows.Forms.Button laughedAtButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceBarButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationPointButton;
    }
}

