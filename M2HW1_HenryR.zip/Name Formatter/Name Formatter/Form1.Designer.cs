﻿namespace Name_Formatter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.titleTextBox = new System.Windows.Forms.TextBox();
            this.firstNameLabel = new System.Windows.Forms.Label();
            this.middleNameLabel = new System.Windows.Forms.Label();
            this.lastNameLabel = new System.Windows.Forms.Label();
            this.titleLabel = new System.Windows.Forms.Label();
            this.titleFullNameButton = new System.Windows.Forms.Button();
            this.fullNameButton = new System.Windows.Forms.Button();
            this.firstNameLastNameButton = new System.Windows.Forms.Button();
            this.reverseTitleFullNameButton = new System.Windows.Forms.Button();
            this.lastNameFirstNameMidNameButton = new System.Windows.Forms.Button();
            this.lastNameFirstNameButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.displayNameLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.titleLabel);
            this.groupBox1.Controls.Add(this.lastNameLabel);
            this.groupBox1.Controls.Add(this.middleNameLabel);
            this.groupBox1.Controls.Add(this.firstNameLabel);
            this.groupBox1.Controls.Add(this.titleTextBox);
            this.groupBox1.Controls.Add(this.lastNameTextBox);
            this.groupBox1.Controls.Add(this.middleNameTextBox);
            this.groupBox1.Controls.Add(this.firstNameTextBox);
            this.groupBox1.Location = new System.Drawing.Point(175, 28);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(270, 193);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Personal Data";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(128, 20);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 0;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(128, 46);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextBox.TabIndex = 1;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(128, 72);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 2;
            // 
            // titleTextBox
            // 
            this.titleTextBox.Location = new System.Drawing.Point(128, 98);
            this.titleTextBox.Name = "titleTextBox";
            this.titleTextBox.Size = new System.Drawing.Size(100, 20);
            this.titleTextBox.TabIndex = 3;
            // 
            // firstNameLabel
            // 
            this.firstNameLabel.AutoSize = true;
            this.firstNameLabel.Location = new System.Drawing.Point(50, 27);
            this.firstNameLabel.Name = "firstNameLabel";
            this.firstNameLabel.Size = new System.Drawing.Size(60, 13);
            this.firstNameLabel.TabIndex = 4;
            this.firstNameLabel.Text = "First Name:";
            // 
            // middleNameLabel
            // 
            this.middleNameLabel.AutoSize = true;
            this.middleNameLabel.Location = new System.Drawing.Point(50, 53);
            this.middleNameLabel.Name = "middleNameLabel";
            this.middleNameLabel.Size = new System.Drawing.Size(72, 13);
            this.middleNameLabel.TabIndex = 5;
            this.middleNameLabel.Text = "Middle Name:";
            // 
            // lastNameLabel
            // 
            this.lastNameLabel.AutoSize = true;
            this.lastNameLabel.Location = new System.Drawing.Point(50, 79);
            this.lastNameLabel.Name = "lastNameLabel";
            this.lastNameLabel.Size = new System.Drawing.Size(61, 13);
            this.lastNameLabel.TabIndex = 6;
            this.lastNameLabel.Text = "Last Name:";
            // 
            // titleLabel
            // 
            this.titleLabel.AutoSize = true;
            this.titleLabel.Location = new System.Drawing.Point(50, 105);
            this.titleLabel.Name = "titleLabel";
            this.titleLabel.Size = new System.Drawing.Size(30, 13);
            this.titleLabel.TabIndex = 7;
            this.titleLabel.Text = "Title:";
            // 
            // titleFullNameButton
            // 
            this.titleFullNameButton.Location = new System.Drawing.Point(119, 242);
            this.titleFullNameButton.Name = "titleFullNameButton";
            this.titleFullNameButton.Size = new System.Drawing.Size(136, 23);
            this.titleFullNameButton.TabIndex = 1;
            this.titleFullNameButton.Text = "Title and Full Name";
            this.titleFullNameButton.UseVisualStyleBackColor = true;
            this.titleFullNameButton.Click += new System.EventHandler(this.titleFullNameButton_Click);
            // 
            // fullNameButton
            // 
            this.fullNameButton.Location = new System.Drawing.Point(261, 243);
            this.fullNameButton.Name = "fullNameButton";
            this.fullNameButton.Size = new System.Drawing.Size(136, 23);
            this.fullNameButton.TabIndex = 2;
            this.fullNameButton.Text = "Full Name";
            this.fullNameButton.UseVisualStyleBackColor = true;
            this.fullNameButton.Click += new System.EventHandler(this.fullNameButton_Click);
            // 
            // firstNameLastNameButton
            // 
            this.firstNameLastNameButton.Location = new System.Drawing.Point(403, 243);
            this.firstNameLastNameButton.Name = "firstNameLastNameButton";
            this.firstNameLastNameButton.Size = new System.Drawing.Size(136, 23);
            this.firstNameLastNameButton.TabIndex = 3;
            this.firstNameLastNameButton.Text = "First and Last Name";
            this.firstNameLastNameButton.UseVisualStyleBackColor = true;
            this.firstNameLastNameButton.Click += new System.EventHandler(this.firstNameLastNameButton_Click);
            // 
            // reverseTitleFullNameButton
            // 
            this.reverseTitleFullNameButton.Location = new System.Drawing.Point(119, 272);
            this.reverseTitleFullNameButton.Name = "reverseTitleFullNameButton";
            this.reverseTitleFullNameButton.Size = new System.Drawing.Size(136, 23);
            this.reverseTitleFullNameButton.TabIndex = 4;
            this.reverseTitleFullNameButton.Text = "Last, First, Middle, Title";
            this.reverseTitleFullNameButton.UseVisualStyleBackColor = true;
            this.reverseTitleFullNameButton.Click += new System.EventHandler(this.reverseTitleFullNameButton_Click);
            // 
            // lastNameFirstNameMidNameButton
            // 
            this.lastNameFirstNameMidNameButton.Location = new System.Drawing.Point(261, 272);
            this.lastNameFirstNameMidNameButton.Name = "lastNameFirstNameMidNameButton";
            this.lastNameFirstNameMidNameButton.Size = new System.Drawing.Size(136, 23);
            this.lastNameFirstNameMidNameButton.TabIndex = 5;
            this.lastNameFirstNameMidNameButton.Text = "last, First, Middle";
            this.lastNameFirstNameMidNameButton.UseVisualStyleBackColor = true;
            this.lastNameFirstNameMidNameButton.Click += new System.EventHandler(this.lastNameFirstNameMidNameButton_Click);
            // 
            // lastNameFirstNameButton
            // 
            this.lastNameFirstNameButton.Location = new System.Drawing.Point(403, 272);
            this.lastNameFirstNameButton.Name = "lastNameFirstNameButton";
            this.lastNameFirstNameButton.Size = new System.Drawing.Size(136, 23);
            this.lastNameFirstNameButton.TabIndex = 6;
            this.lastNameFirstNameButton.Text = "last and First Name";
            this.lastNameFirstNameButton.UseVisualStyleBackColor = true;
            this.lastNameFirstNameButton.Click += new System.EventHandler(this.lastNameFirstNameButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(322, 370);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // displayNameLabel
            // 
            this.displayNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayNameLabel.Location = new System.Drawing.Point(175, 313);
            this.displayNameLabel.Name = "displayNameLabel";
            this.displayNameLabel.Size = new System.Drawing.Size(270, 23);
            this.displayNameLabel.TabIndex = 8;
            this.displayNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(241, 370);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 9;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(616, 405);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.displayNameLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.lastNameFirstNameButton);
            this.Controls.Add(this.lastNameFirstNameMidNameButton);
            this.Controls.Add(this.reverseTitleFullNameButton);
            this.Controls.Add(this.firstNameLastNameButton);
            this.Controls.Add(this.fullNameButton);
            this.Controls.Add(this.titleFullNameButton);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label titleLabel;
        private System.Windows.Forms.Label lastNameLabel;
        private System.Windows.Forms.Label middleNameLabel;
        private System.Windows.Forms.Label firstNameLabel;
        private System.Windows.Forms.TextBox titleTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.Button titleFullNameButton;
        private System.Windows.Forms.Button fullNameButton;
        private System.Windows.Forms.Button firstNameLastNameButton;
        private System.Windows.Forms.Button reverseTitleFullNameButton;
        private System.Windows.Forms.Button lastNameFirstNameMidNameButton;
        private System.Windows.Forms.Button lastNameFirstNameButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label displayNameLabel;
        private System.Windows.Forms.Button clearButton;
    }
}

