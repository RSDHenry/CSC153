﻿/**
* 12 FEB 2018
* CSC 153
* Rashad Henry
* A program that displays formatted input for each appropriate button
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Name_Formatter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void titleFullNameButton_Click(object sender, EventArgs e)
        {
            // Declare a string variable to hold the title, first name, middle name, and last name.
            string titleFullName;

            // Combine the names and assign the result to the titleFullName variable.
            titleFullName = titleTextBox.Text + firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text;

            // Display 
            displayNameLabel.Text = titleFullName;
        }

        private void fullNameButton_Click(object sender, EventArgs e)
        {
            // Declare a string variable to hold the first name, middle name, and last name.
            string fullName;

            // Combine the names and assign the result to the fullName variable.
            fullName = firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + lastNameTextBox.Text + " ";

            // Display
            displayNameLabel.Text = fullName;
        }

        private void firstNameLastNameButton_Click(object sender, EventArgs e)
        {
            // Declare a string variable to hold the first name and last name.
            string firstNameLastName;

            // Combine the names and assign the result to the firstNameLastName variable.
            firstNameLastName = firstNameTextBox.Text + " " + lastNameTextBox.Text;

            //Display
            displayNameLabel.Text = firstNameLastName;
        }

        private void reverseTitleFullNameButton_Click(object sender, EventArgs e)
        {
            // Declare a string variable to hold the last name, first name, middle name, and title.
            string reverseFullNameTitle;

            // Combine the names and assign the result to the reverseFullNameTitle variable.
            reverseFullNameTitle = lastNameTextBox.Text + " " + firstNameTextBox.Text + " " + middleNameTextBox.Text + " " + titleTextBox.Text;

            // Display
            displayNameLabel.Text = reverseFullNameTitle;
        }

        private void lastNameFirstNameMidNameButton_Click(object sender, EventArgs e)
        {
            // Declare a string variable to hold the last name, first name, and middle name.
            string lastFirstMiddleName;

            // Combine the names and assign the result to the lastFirstMiddleName variable.
            lastFirstMiddleName = lastNameTextBox.Text + " " + firstNameTextBox.Text + " " + middleNameTextBox.Text;

            // Display
            displayNameLabel.Text = lastFirstMiddleName;
        }

        private void lastNameFirstNameButton_Click(object sender, EventArgs e)
        {
            // Declare a string variable to hold the last name and first name.
            string lastNameFirstName;

            // Combine the names and assign the result to the lastNameFirstName variable.
            lastNameFirstName = lastNameTextBox.Text + " " + firstNameTextBox.Text;

            // Display
            displayNameLabel.Text = lastNameFirstName;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the text boxes.
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            titleTextBox.Text = "";

            // Clear the display name label.
            displayNameLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
