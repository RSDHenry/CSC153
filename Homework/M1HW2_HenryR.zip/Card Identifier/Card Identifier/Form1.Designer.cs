﻿namespace Card_Identifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.instructionLabel = new System.Windows.Forms.Label();
            this.sixOfClubsPictureBox = new System.Windows.Forms.PictureBox();
            this.tenOfHeartsPictureBox = new System.Windows.Forms.PictureBox();
            this.threeOfSpadesPictureBox = new System.Windows.Forms.PictureBox();
            this.kingOfDiamondsPictureBox = new System.Windows.Forms.PictureBox();
            this.fiveOfClubsPictureBox = new System.Windows.Forms.PictureBox();
            this.selectionLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.sixOfClubsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenOfHeartsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeOfSpadesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfDiamondsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveOfClubsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // instructionLabel
            // 
            this.instructionLabel.AutoSize = true;
            this.instructionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.instructionLabel.Location = new System.Drawing.Point(323, 38);
            this.instructionLabel.Name = "instructionLabel";
            this.instructionLabel.Size = new System.Drawing.Size(275, 24);
            this.instructionLabel.TabIndex = 0;
            this.instructionLabel.Text = "Click a Card to See Its Name";
            // 
            // sixOfClubsPictureBox
            // 
            this.sixOfClubsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("sixOfClubsPictureBox.Image")));
            this.sixOfClubsPictureBox.Location = new System.Drawing.Point(30, 112);
            this.sixOfClubsPictureBox.Name = "sixOfClubsPictureBox";
            this.sixOfClubsPictureBox.Size = new System.Drawing.Size(155, 182);
            this.sixOfClubsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.sixOfClubsPictureBox.TabIndex = 1;
            this.sixOfClubsPictureBox.TabStop = false;
            this.sixOfClubsPictureBox.Click += new System.EventHandler(this.sixOfClubsPictureBox_Click);
            // 
            // tenOfHeartsPictureBox
            // 
            this.tenOfHeartsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("tenOfHeartsPictureBox.Image")));
            this.tenOfHeartsPictureBox.Location = new System.Drawing.Point(218, 112);
            this.tenOfHeartsPictureBox.Name = "tenOfHeartsPictureBox";
            this.tenOfHeartsPictureBox.Size = new System.Drawing.Size(135, 182);
            this.tenOfHeartsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.tenOfHeartsPictureBox.TabIndex = 2;
            this.tenOfHeartsPictureBox.TabStop = false;
            this.tenOfHeartsPictureBox.Click += new System.EventHandler(this.tenOfHeartsPictureBox_Click);
            // 
            // threeOfSpadesPictureBox
            // 
            this.threeOfSpadesPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("threeOfSpadesPictureBox.Image")));
            this.threeOfSpadesPictureBox.Location = new System.Drawing.Point(388, 112);
            this.threeOfSpadesPictureBox.Name = "threeOfSpadesPictureBox";
            this.threeOfSpadesPictureBox.Size = new System.Drawing.Size(136, 182);
            this.threeOfSpadesPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.threeOfSpadesPictureBox.TabIndex = 3;
            this.threeOfSpadesPictureBox.TabStop = false;
            this.threeOfSpadesPictureBox.Click += new System.EventHandler(this.threeOfSpadesPictureBox_Click);
            // 
            // kingOfDiamondsPictureBox
            // 
            this.kingOfDiamondsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("kingOfDiamondsPictureBox.Image")));
            this.kingOfDiamondsPictureBox.Location = new System.Drawing.Point(551, 112);
            this.kingOfDiamondsPictureBox.Name = "kingOfDiamondsPictureBox";
            this.kingOfDiamondsPictureBox.Size = new System.Drawing.Size(136, 182);
            this.kingOfDiamondsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.kingOfDiamondsPictureBox.TabIndex = 4;
            this.kingOfDiamondsPictureBox.TabStop = false;
            this.kingOfDiamondsPictureBox.Click += new System.EventHandler(this.kingOfDiamondsPictureBox_Click);
            // 
            // fiveOfClubsPictureBox
            // 
            this.fiveOfClubsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("fiveOfClubsPictureBox.Image")));
            this.fiveOfClubsPictureBox.Location = new System.Drawing.Point(711, 112);
            this.fiveOfClubsPictureBox.Name = "fiveOfClubsPictureBox";
            this.fiveOfClubsPictureBox.Size = new System.Drawing.Size(151, 182);
            this.fiveOfClubsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.fiveOfClubsPictureBox.TabIndex = 5;
            this.fiveOfClubsPictureBox.TabStop = false;
            this.fiveOfClubsPictureBox.Click += new System.EventHandler(this.fiveOfClubsPictureBox_Click);
            // 
            // selectionLabel
            // 
            this.selectionLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.selectionLabel.Location = new System.Drawing.Point(218, 320);
            this.selectionLabel.Name = "selectionLabel";
            this.selectionLabel.Size = new System.Drawing.Size(469, 23);
            this.selectionLabel.TabIndex = 6;
            this.selectionLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(416, 364);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(898, 410);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.selectionLabel);
            this.Controls.Add(this.fiveOfClubsPictureBox);
            this.Controls.Add(this.kingOfDiamondsPictureBox);
            this.Controls.Add(this.threeOfSpadesPictureBox);
            this.Controls.Add(this.tenOfHeartsPictureBox);
            this.Controls.Add(this.sixOfClubsPictureBox);
            this.Controls.Add(this.instructionLabel);
            this.Name = "Form1";
            this.Text = "Card Identifier";
            ((System.ComponentModel.ISupportInitialize)(this.sixOfClubsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenOfHeartsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.threeOfSpadesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.kingOfDiamondsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.fiveOfClubsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label instructionLabel;
        private System.Windows.Forms.PictureBox sixOfClubsPictureBox;
        private System.Windows.Forms.PictureBox tenOfHeartsPictureBox;
        private System.Windows.Forms.PictureBox threeOfSpadesPictureBox;
        private System.Windows.Forms.PictureBox kingOfDiamondsPictureBox;
        private System.Windows.Forms.PictureBox fiveOfClubsPictureBox;
        private System.Windows.Forms.Label selectionLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

