﻿/**
* 29 January 2018
* CSC 153
* Rashad Henry
* Program that identifies a card when selected
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Card_Identifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sixOfClubsPictureBox_Click(object sender, EventArgs e)
        {
            selectionLabel.Text = "Six of Clubs";
        }

        private void tenOfHeartsPictureBox_Click(object sender, EventArgs e)
        {
            selectionLabel.Text = "Ten of Hearts";
        }

        private void threeOfSpadesPictureBox_Click(object sender, EventArgs e)
        {
            selectionLabel.Text = "Three of Spades";
        }

        private void kingOfDiamondsPictureBox_Click(object sender, EventArgs e)
        {
            selectionLabel.Text = "King of Diamonds";
        }

        private void fiveOfClubsPictureBox_Click(object sender, EventArgs e)
        {
            selectionLabel.Text = "Five of Clubs";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
