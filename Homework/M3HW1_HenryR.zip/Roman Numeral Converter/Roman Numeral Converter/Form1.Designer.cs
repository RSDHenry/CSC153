﻿namespace Roman_Numeral_Converter
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.integerTextBox = new System.Windows.Forms.TextBox();
            this.displayRomanLabel = new System.Windows.Forms.Label();
            this.numbersGroupBox = new System.Windows.Forms.GroupBox();
            this.showRomanNumeralButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.numbersGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // integerTextBox
            // 
            this.integerTextBox.Location = new System.Drawing.Point(63, 29);
            this.integerTextBox.Name = "integerTextBox";
            this.integerTextBox.Size = new System.Drawing.Size(100, 20);
            this.integerTextBox.TabIndex = 0;
            this.integerTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // displayRomanLabel
            // 
            this.displayRomanLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayRomanLabel.Location = new System.Drawing.Point(63, 68);
            this.displayRomanLabel.Name = "displayRomanLabel";
            this.displayRomanLabel.Size = new System.Drawing.Size(100, 23);
            this.displayRomanLabel.TabIndex = 1;
            this.displayRomanLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // numbersGroupBox
            // 
            this.numbersGroupBox.Controls.Add(this.displayRomanLabel);
            this.numbersGroupBox.Controls.Add(this.integerTextBox);
            this.numbersGroupBox.Location = new System.Drawing.Point(57, 30);
            this.numbersGroupBox.Name = "numbersGroupBox";
            this.numbersGroupBox.Size = new System.Drawing.Size(233, 131);
            this.numbersGroupBox.TabIndex = 2;
            this.numbersGroupBox.TabStop = false;
            this.numbersGroupBox.Text = "Enter A Number Between 1 and 10";
            // 
            // showRomanNumeralButton
            // 
            this.showRomanNumeralButton.Location = new System.Drawing.Point(92, 167);
            this.showRomanNumeralButton.Name = "showRomanNumeralButton";
            this.showRomanNumeralButton.Size = new System.Drawing.Size(75, 54);
            this.showRomanNumeralButton.TabIndex = 3;
            this.showRomanNumeralButton.Text = "Show Roman Numeral";
            this.showRomanNumeralButton.UseVisualStyleBackColor = true;
            this.showRomanNumeralButton.Click += new System.EventHandler(this.showRomanNumeralButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(182, 167);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 4;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(182, 196);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 5;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 234);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.showRomanNumeralButton);
            this.Controls.Add(this.numbersGroupBox);
            this.Name = "Form1";
            this.Text = "Roman Numeral Converter";
            this.numbersGroupBox.ResumeLayout(false);
            this.numbersGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox integerTextBox;
        private System.Windows.Forms.Label displayRomanLabel;
        private System.Windows.Forms.GroupBox numbersGroupBox;
        private System.Windows.Forms.Button showRomanNumeralButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

