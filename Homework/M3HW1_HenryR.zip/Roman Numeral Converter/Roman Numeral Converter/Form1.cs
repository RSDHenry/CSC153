﻿/**
* 26 FEB 2018
* CSC 153
* Rashad Henry
* A program that converts integers into roman numerals.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Roman_Numeral_Converter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showRomanNumeralButton_Click(object sender, EventArgs e)
        {
            
            {
                // variable to hold the user input
                int userInput;

                // Get the integer
                userInput = int.Parse(integerTextBox.Text);

                // Take the integer input and convert to roman numeral.
                if (userInput == 1) 
                {
                    displayRomanLabel.Text = "I";
                }
                else if (userInput == 2)
                {
                    displayRomanLabel.Text = "II";
                }
                else if (userInput == 3)
                {
                    displayRomanLabel.Text = "III";
                }
                else if (userInput == 4)
                {
                    displayRomanLabel.Text = "IV";
                }
                else if (userInput == 5)
                {
                    displayRomanLabel.Text = "V";
                }
                else if (userInput == 6)
                {
                    displayRomanLabel.Text = "VI";
                }
                else if (userInput == 7)
                {
                    displayRomanLabel.Text = "VII";
                }
                else if (userInput == 8)
                {
                    displayRomanLabel.Text = "VIII";
                }
                else if (userInput == 9)
                {
                    displayRomanLabel.Text = "IX";
                }
                else if (userInput == 10)
                {
                    displayRomanLabel.Text = "X";
                }
                if (userInput < 1 || userInput > 10)
                    MessageBox.Show("Error, The number must be between 1 and 10"); 
                }

            }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the form
            displayRomanLabel.Text = "";
            integerTextBox.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the program
            this.Close();
        }
    }
    }
