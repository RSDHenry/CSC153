﻿/**
* 17 April 2018
* CSC 153
* Rashad Henry
* This program has a user created method to calculate the 
* distance an object has fallen in using a gravity formula and 
* displaying the results to the user.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Falling_Distance
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Declare variables.
            double distanceValue;
            double time;

            // Convert the string to a double.
            time = double.Parse(secondsTextBox.Text);

            // Create a method named FallingDistance and pass the objects
            // falling time in seconds as an arugment. 
            distanceValue = FallingDistance(time);
            // Display the results in a message box. 
            MessageBox.Show("The distance the object has fallen is "
                + distanceValue + " meters.");
        }
            
            /** Formula to determine the distance the object falls in a specific
             time period.
             d=1/2*g*t^2 
             d = distance in meters.
             g = gravity and the value is 9.8.
             t = time in seconds the object has been falling.
             */

            // Method that calculates the distance an object has fallen using
            // the forumla above.
         private double FallingDistance(double time)
        {
            // Return the calculated distance.
            return 0.5 * 9.8 * (time*=time);
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // Clear the input in the textbox.
            secondsTextBox.Text = "";
        }
    }
}