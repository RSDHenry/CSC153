﻿/**
* 25 March 2018
* CSC 153
* Rashad Henry
* This program calculates the population
* of organisms given a percentage in daily
* increase and the number of days of growth.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Population
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {

            // Declare variables.
            double numOfOrganism;
            double dailyIncrease;
            int numOfDays;       
            int count = 1;   


            // This loop will convert the textvoxes to a double and integer.
                if (double.TryParse(numOfOrganismsTextBox.Text, out numOfOrganism)
                && double.TryParse(dailyIncreaseTextBox.Text, out dailyIncrease)
                && int.TryParse(daysToMultiplyTextBox.Text, out numOfDays))
            {
               populationListBox.Items.Add("Day             Approximate Population");
                // This statement ensures that the dailyIncrease is considered as a percentage.
                dailyIncrease /= 100;

                while (count <= numOfDays)
                {

                    // Prints out the initial value.
                    populationListBox.Items.Add(count + "                       " + numOfOrganism);

                    // Add one to the loop counter.
                    count = count + 1;
                    // Perform calculation for the population.
                    numOfOrganism += numOfOrganism * dailyIncrease;
                }

            }
            else
            {
                MessageBox.Show("Invalid input.");
            }
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            populationListBox.Items.Clear();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
