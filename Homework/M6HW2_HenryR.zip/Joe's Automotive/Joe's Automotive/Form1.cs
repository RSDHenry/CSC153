﻿/**
* 18 April 2018
* CSC 153
* Rashad Henry
* This program uses methods to calculate a customer's
* bill after getting service from Joe's Automotive.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Joe_s_Automotive
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            // Declare variables.
            double oilChange = 0;
            double lubeJob = 0;
            double inspection = 0;
            double replaceMuffler = 0;
            double tireRotation = 0;
            double radiatorFlush = 0;
            double transFlush = 0;
            
            // Store the appropriate values if check box is checked.
            if (oilChangeCheckBox.Checked == true)
            {
                oilChange = 26;
            }
            if (lubeJobCheckBox.Checked == true)
            {
                lubeJob = 18;
            }
            if (inspectionCheckBox.Checked == true)
            {
                inspection = 15;
            }
            if (replaceMufflerCheckBox.Checked == true)
            {
                replaceMuffler = 100;
            }
            if (tireRotationCheckBox.Checked == true)
            {
                tireRotation = 20;
            }
            if (radFlushCheckBox.Checked == true)
            {
                radiatorFlush = 30;
            }
            if (transFlushCheckBox.Checked == true)
            {
                transFlush = 80;
            }

            // Get the input values from the parts and labor textbbox 
            //and convert the strings to doubles.
            double parts = double.Parse(partsTextBox.Text);
            double labor = double.Parse(laborTextBox.Text);

            // Pass the values of all the services as parameters and return the
            // value that is stored for the functions.
            double oilAndLubeServices = OilLubeCharges (oilChange, lubeJob);
            double flushServices = FlushCharges (radiatorFlush, transFlush);
            double miscServices = MiscCharges (inspection, replaceMuffler, tireRotation);
            double partsAndLaborServices = OtherCharges (parts, labor);
            double taxOnParts = TaxCharges (parts, labor, oilAndLubeServices, flushServices, miscServices, partsAndLaborServices);
            double total = TotalCharges(oilAndLubeServices, flushServices, miscServices, partsAndLaborServices, taxOnParts);

            // Calculate the total for the auto service and display the value and display
            // the costs for service & labor, parts, tax, and the total bill.
            double autoService = oilAndLubeServices + flushServices + miscServices;
            serviceAndLaborTextBox.Text = autoService.ToString();
            partsSumTextBox.Text = partsAndLaborServices.ToString();
            taxOnPartsTextBox.Text = taxOnParts.ToString();
            totalFeesTextBox.Text = total.ToString();
        }

        // Create methods for each auto service.
        private double OilLubeCharges (double oilChange, double lubeJob)
        {
            // Returns the charges for selecting an oil change and lube job.
            return oilChange + lubeJob;
        }

        private double FlushCharges (double radiatorFlush, double transFlush)
        {
            // Returns the charges for selecting an radiator flush and transmission flush.
            return radiatorFlush + transFlush;
        }

        private double MiscCharges (double inspection, double replaceMuffler, double tireRotation)
        {
            // Returns the charges for selecting a inspection, muffler replacement, and tire rotation.
            return inspection + replaceMuffler + tireRotation;
        }

        private double OtherCharges (double parts, double labor)
        {
            // Returns the charges for parts purchased and labor during service.
            return parts + labor;
        }

            // Calculates the sales tax and returns the value if conditions are met.
        private double TaxCharges (double parts, double labor, double oilAndLubeServices, 
            double flushServices, double miscServices, double partsAndLaborServices)
        {
            if (parts != 0 && labor != 0 && (oilAndLubeServices != 0 && flushServices != 0
                && miscServices != 0 && partsAndLaborServices != 0))
            {
                // Sales tax on parts is 6%.
                return (0.06 * parts);
            }

            else
                return 0;
        }

        private double TotalCharges (double oilAndLubeSerices, double flushServices, 
            double miscServices, double partsAndLaborServices, double taxOnParts)
        {
            // Returns the charges for selecting the above services plus the tax and 
            //charges for parts and labor for the total charge.
            return oilAndLubeSerices + flushServices + miscServices + partsAndLaborServices + taxOnParts;
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // When the clear button is clicked the clearButton function will call
            // all the clear functions and clear all the data in the groupboxes.
            ClearOilLube();
            ClearFlushes();
            ClearMisc();
            ClearOther();
            ClearFees();
        }

        private void ClearOilLube()
        {
            // Will check if box is selected and will set the values to false if so.
            if (oilChangeCheckBox.Checked == true)
            {
                oilChangeCheckBox.Checked = false;
            }
            if (lubeJobCheckBox.Checked == true)
            {
                lubeJobCheckBox.Checked = false;
            }
        }

        private void ClearFlushes()
        {
            // Will check if box is selected and will set the values to false if so.
            if (radFlushCheckBox.Checked == true)
            {
                radFlushCheckBox.Checked = false;
            }
            if (transFlushCheckBox.Checked == true)
            {
                transFlushCheckBox.Checked = false;
            }
        }
        
        private void ClearMisc()
        {
            // Will check if box is selected and will set the values to false if so.
            if (inspectionCheckBox.Checked == true)
            {
                inspectionCheckBox.Checked = false;
            }
            if (replaceMufflerCheckBox.Checked == true)
            {
                replaceMufflerCheckBox.Checked = false;
            }
            if (tireRotationCheckBox.Checked == true)
            {
                tireRotationCheckBox.Checked = false;
            }
        }
        
        private void ClearOther()
        {
            // Will clear the data in the parts and labor textboxes.
            partsTextBox.Text = null;
            laborTextBox.Text = null;
        }
        
        private void ClearFees()
        {
            // Will clear the data in the summary group box.
            serviceAndLaborTextBox.Text = null;
            partsSumTextBox.Text = null;
            taxOnPartsTextBox.Text = null;
            totalFeesTextBox.Text = null;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
