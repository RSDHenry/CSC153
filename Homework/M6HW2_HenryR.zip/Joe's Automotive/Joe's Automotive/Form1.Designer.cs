﻿namespace Joe_s_Automotive
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.oilAndLubeGroupBox = new System.Windows.Forms.GroupBox();
            this.lubeJobCheckBox = new System.Windows.Forms.CheckBox();
            this.oilChangeCheckBox = new System.Windows.Forms.CheckBox();
            this.miscGroupBox = new System.Windows.Forms.GroupBox();
            this.tireRotationCheckBox = new System.Windows.Forms.CheckBox();
            this.replaceMufflerCheckBox = new System.Windows.Forms.CheckBox();
            this.inspectionCheckBox = new System.Windows.Forms.CheckBox();
            this.flushesGroupBox = new System.Windows.Forms.GroupBox();
            this.transFlushCheckBox = new System.Windows.Forms.CheckBox();
            this.radFlushCheckBox = new System.Windows.Forms.CheckBox();
            this.partsAndLaborGroupBox = new System.Windows.Forms.GroupBox();
            this.laborLabel = new System.Windows.Forms.Label();
            this.partsLabel = new System.Windows.Forms.Label();
            this.laborTextBox = new System.Windows.Forms.TextBox();
            this.partsTextBox = new System.Windows.Forms.TextBox();
            this.summaryGroupBox = new System.Windows.Forms.GroupBox();
            this.totalFeesTextBox = new System.Windows.Forms.TextBox();
            this.taxOnPartsTextBox = new System.Windows.Forms.TextBox();
            this.partsSumTextBox = new System.Windows.Forms.TextBox();
            this.serviceAndLaborTextBox = new System.Windows.Forms.TextBox();
            this.totalFeesLabel = new System.Windows.Forms.Label();
            this.taxLabel = new System.Windows.Forms.Label();
            this.partsSummaryLabel = new System.Windows.Forms.Label();
            this.serviceAndLaborLabel = new System.Windows.Forms.Label();
            this.calculateButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.oilAndLubeGroupBox.SuspendLayout();
            this.miscGroupBox.SuspendLayout();
            this.flushesGroupBox.SuspendLayout();
            this.partsAndLaborGroupBox.SuspendLayout();
            this.summaryGroupBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // oilAndLubeGroupBox
            // 
            this.oilAndLubeGroupBox.Controls.Add(this.lubeJobCheckBox);
            this.oilAndLubeGroupBox.Controls.Add(this.oilChangeCheckBox);
            this.oilAndLubeGroupBox.Location = new System.Drawing.Point(12, 12);
            this.oilAndLubeGroupBox.Name = "oilAndLubeGroupBox";
            this.oilAndLubeGroupBox.Size = new System.Drawing.Size(200, 79);
            this.oilAndLubeGroupBox.TabIndex = 0;
            this.oilAndLubeGroupBox.TabStop = false;
            this.oilAndLubeGroupBox.Text = "Oil and Lube";
            // 
            // lubeJobCheckBox
            // 
            this.lubeJobCheckBox.AutoSize = true;
            this.lubeJobCheckBox.Location = new System.Drawing.Point(6, 42);
            this.lubeJobCheckBox.Name = "lubeJobCheckBox";
            this.lubeJobCheckBox.Size = new System.Drawing.Size(109, 17);
            this.lubeJobCheckBox.TabIndex = 2;
            this.lubeJobCheckBox.Text = "Lube job ($18.00)";
            this.lubeJobCheckBox.UseVisualStyleBackColor = true;
            // 
            // oilChangeCheckBox
            // 
            this.oilChangeCheckBox.AutoSize = true;
            this.oilChangeCheckBox.Location = new System.Drawing.Point(6, 19);
            this.oilChangeCheckBox.Name = "oilChangeCheckBox";
            this.oilChangeCheckBox.Size = new System.Drawing.Size(120, 17);
            this.oilChangeCheckBox.TabIndex = 1;
            this.oilChangeCheckBox.Text = "Oil Change ($26.00)";
            this.oilChangeCheckBox.UseVisualStyleBackColor = true;
            // 
            // miscGroupBox
            // 
            this.miscGroupBox.Controls.Add(this.tireRotationCheckBox);
            this.miscGroupBox.Controls.Add(this.replaceMufflerCheckBox);
            this.miscGroupBox.Controls.Add(this.inspectionCheckBox);
            this.miscGroupBox.Location = new System.Drawing.Point(12, 97);
            this.miscGroupBox.Name = "miscGroupBox";
            this.miscGroupBox.Size = new System.Drawing.Size(200, 100);
            this.miscGroupBox.TabIndex = 1;
            this.miscGroupBox.TabStop = false;
            this.miscGroupBox.Text = "Misc";
            // 
            // tireRotationCheckBox
            // 
            this.tireRotationCheckBox.AutoSize = true;
            this.tireRotationCheckBox.Location = new System.Drawing.Point(6, 67);
            this.tireRotationCheckBox.Name = "tireRotationCheckBox";
            this.tireRotationCheckBox.Size = new System.Drawing.Size(129, 17);
            this.tireRotationCheckBox.TabIndex = 2;
            this.tireRotationCheckBox.Text = "Tire Rotation ($20.00)";
            this.tireRotationCheckBox.UseVisualStyleBackColor = true;
            // 
            // replaceMufflerCheckBox
            // 
            this.replaceMufflerCheckBox.AutoSize = true;
            this.replaceMufflerCheckBox.Location = new System.Drawing.Point(6, 43);
            this.replaceMufflerCheckBox.Name = "replaceMufflerCheckBox";
            this.replaceMufflerCheckBox.Size = new System.Drawing.Size(149, 17);
            this.replaceMufflerCheckBox.TabIndex = 1;
            this.replaceMufflerCheckBox.Text = "Replace Muffler ($100.00)";
            this.replaceMufflerCheckBox.UseVisualStyleBackColor = true;
            // 
            // inspectionCheckBox
            // 
            this.inspectionCheckBox.AutoSize = true;
            this.inspectionCheckBox.Location = new System.Drawing.Point(6, 20);
            this.inspectionCheckBox.Name = "inspectionCheckBox";
            this.inspectionCheckBox.Size = new System.Drawing.Size(117, 17);
            this.inspectionCheckBox.TabIndex = 0;
            this.inspectionCheckBox.Text = "Insepction ($15.00)";
            this.inspectionCheckBox.UseVisualStyleBackColor = true;
            // 
            // flushesGroupBox
            // 
            this.flushesGroupBox.Controls.Add(this.transFlushCheckBox);
            this.flushesGroupBox.Controls.Add(this.radFlushCheckBox);
            this.flushesGroupBox.Location = new System.Drawing.Point(218, 12);
            this.flushesGroupBox.Name = "flushesGroupBox";
            this.flushesGroupBox.Size = new System.Drawing.Size(200, 79);
            this.flushesGroupBox.TabIndex = 2;
            this.flushesGroupBox.TabStop = false;
            this.flushesGroupBox.Text = "Flushes";
            // 
            // transFlushCheckBox
            // 
            this.transFlushCheckBox.AutoSize = true;
            this.transFlushCheckBox.Location = new System.Drawing.Point(7, 42);
            this.transFlushCheckBox.Name = "transFlushCheckBox";
            this.transFlushCheckBox.Size = new System.Drawing.Size(157, 17);
            this.transFlushCheckBox.TabIndex = 1;
            this.transFlushCheckBox.Text = "Transmission Flush ($80.00)";
            this.transFlushCheckBox.UseVisualStyleBackColor = true;
            // 
            // radFlushCheckBox
            // 
            this.radFlushCheckBox.AutoSize = true;
            this.radFlushCheckBox.Location = new System.Drawing.Point(7, 19);
            this.radFlushCheckBox.Name = "radFlushCheckBox";
            this.radFlushCheckBox.Size = new System.Drawing.Size(136, 17);
            this.radFlushCheckBox.TabIndex = 0;
            this.radFlushCheckBox.Text = "Radiator Flush ($30.00)";
            this.radFlushCheckBox.UseVisualStyleBackColor = true;
            // 
            // partsAndLaborGroupBox
            // 
            this.partsAndLaborGroupBox.Controls.Add(this.laborLabel);
            this.partsAndLaborGroupBox.Controls.Add(this.partsLabel);
            this.partsAndLaborGroupBox.Controls.Add(this.laborTextBox);
            this.partsAndLaborGroupBox.Controls.Add(this.partsTextBox);
            this.partsAndLaborGroupBox.Location = new System.Drawing.Point(218, 97);
            this.partsAndLaborGroupBox.Name = "partsAndLaborGroupBox";
            this.partsAndLaborGroupBox.Size = new System.Drawing.Size(200, 100);
            this.partsAndLaborGroupBox.TabIndex = 3;
            this.partsAndLaborGroupBox.TabStop = false;
            this.partsAndLaborGroupBox.Text = "Parts and Labor";
            // 
            // laborLabel
            // 
            this.laborLabel.Location = new System.Drawing.Point(35, 45);
            this.laborLabel.Name = "laborLabel";
            this.laborLabel.Size = new System.Drawing.Size(53, 23);
            this.laborLabel.TabIndex = 3;
            this.laborLabel.Text = "Labor ($)";
            // 
            // partsLabel
            // 
            this.partsLabel.Location = new System.Drawing.Point(44, 18);
            this.partsLabel.Name = "partsLabel";
            this.partsLabel.Size = new System.Drawing.Size(44, 23);
            this.partsLabel.TabIndex = 2;
            this.partsLabel.Text = "Parts";
            // 
            // laborTextBox
            // 
            this.laborTextBox.Location = new System.Drawing.Point(94, 45);
            this.laborTextBox.Name = "laborTextBox";
            this.laborTextBox.Size = new System.Drawing.Size(70, 20);
            this.laborTextBox.TabIndex = 1;
            this.laborTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // partsTextBox
            // 
            this.partsTextBox.Location = new System.Drawing.Point(94, 18);
            this.partsTextBox.Name = "partsTextBox";
            this.partsTextBox.Size = new System.Drawing.Size(70, 20);
            this.partsTextBox.TabIndex = 0;
            this.partsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // summaryGroupBox
            // 
            this.summaryGroupBox.Controls.Add(this.totalFeesTextBox);
            this.summaryGroupBox.Controls.Add(this.taxOnPartsTextBox);
            this.summaryGroupBox.Controls.Add(this.partsSumTextBox);
            this.summaryGroupBox.Controls.Add(this.serviceAndLaborTextBox);
            this.summaryGroupBox.Controls.Add(this.totalFeesLabel);
            this.summaryGroupBox.Controls.Add(this.taxLabel);
            this.summaryGroupBox.Controls.Add(this.partsSummaryLabel);
            this.summaryGroupBox.Controls.Add(this.serviceAndLaborLabel);
            this.summaryGroupBox.Location = new System.Drawing.Point(12, 203);
            this.summaryGroupBox.Name = "summaryGroupBox";
            this.summaryGroupBox.Size = new System.Drawing.Size(406, 149);
            this.summaryGroupBox.TabIndex = 4;
            this.summaryGroupBox.TabStop = false;
            this.summaryGroupBox.Text = "Summary";
            // 
            // totalFeesTextBox
            // 
            this.totalFeesTextBox.Location = new System.Drawing.Point(109, 116);
            this.totalFeesTextBox.Name = "totalFeesTextBox";
            this.totalFeesTextBox.Size = new System.Drawing.Size(110, 20);
            this.totalFeesTextBox.TabIndex = 7;
            this.totalFeesTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // taxOnPartsTextBox
            // 
            this.taxOnPartsTextBox.Location = new System.Drawing.Point(110, 83);
            this.taxOnPartsTextBox.Name = "taxOnPartsTextBox";
            this.taxOnPartsTextBox.Size = new System.Drawing.Size(109, 20);
            this.taxOnPartsTextBox.TabIndex = 6;
            this.taxOnPartsTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // partsSumTextBox
            // 
            this.partsSumTextBox.Location = new System.Drawing.Point(110, 51);
            this.partsSumTextBox.Name = "partsSumTextBox";
            this.partsSumTextBox.Size = new System.Drawing.Size(109, 20);
            this.partsSumTextBox.TabIndex = 5;
            this.partsSumTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // serviceAndLaborTextBox
            // 
            this.serviceAndLaborTextBox.Location = new System.Drawing.Point(110, 17);
            this.serviceAndLaborTextBox.Name = "serviceAndLaborTextBox";
            this.serviceAndLaborTextBox.Size = new System.Drawing.Size(109, 20);
            this.serviceAndLaborTextBox.TabIndex = 4;
            this.serviceAndLaborTextBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // totalFeesLabel
            // 
            this.totalFeesLabel.Location = new System.Drawing.Point(3, 116);
            this.totalFeesLabel.Name = "totalFeesLabel";
            this.totalFeesLabel.Size = new System.Drawing.Size(100, 23);
            this.totalFeesLabel.TabIndex = 3;
            this.totalFeesLabel.Text = "Total Fees";
            this.totalFeesLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // taxLabel
            // 
            this.taxLabel.Location = new System.Drawing.Point(3, 83);
            this.taxLabel.Name = "taxLabel";
            this.taxLabel.Size = new System.Drawing.Size(100, 23);
            this.taxLabel.TabIndex = 2;
            this.taxLabel.Text = "Tax (on parts)";
            this.taxLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // partsSummaryLabel
            // 
            this.partsSummaryLabel.Location = new System.Drawing.Point(6, 48);
            this.partsSummaryLabel.Name = "partsSummaryLabel";
            this.partsSummaryLabel.Size = new System.Drawing.Size(100, 23);
            this.partsSummaryLabel.TabIndex = 1;
            this.partsSummaryLabel.Text = "Parts";
            this.partsSummaryLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // serviceAndLaborLabel
            // 
            this.serviceAndLaborLabel.Location = new System.Drawing.Point(3, 15);
            this.serviceAndLaborLabel.Name = "serviceAndLaborLabel";
            this.serviceAndLaborLabel.Size = new System.Drawing.Size(100, 23);
            this.serviceAndLaborLabel.TabIndex = 0;
            this.serviceAndLaborLabel.Text = "Service and Labor";
            this.serviceAndLaborLabel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(103, 376);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 5;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(184, 376);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 23);
            this.clearButton.TabIndex = 6;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(265, 376);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(444, 423);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.summaryGroupBox);
            this.Controls.Add(this.partsAndLaborGroupBox);
            this.Controls.Add(this.flushesGroupBox);
            this.Controls.Add(this.miscGroupBox);
            this.Controls.Add(this.oilAndLubeGroupBox);
            this.Name = "Form1";
            this.Text = "Automotive";
            this.oilAndLubeGroupBox.ResumeLayout(false);
            this.oilAndLubeGroupBox.PerformLayout();
            this.miscGroupBox.ResumeLayout(false);
            this.miscGroupBox.PerformLayout();
            this.flushesGroupBox.ResumeLayout(false);
            this.flushesGroupBox.PerformLayout();
            this.partsAndLaborGroupBox.ResumeLayout(false);
            this.partsAndLaborGroupBox.PerformLayout();
            this.summaryGroupBox.ResumeLayout(false);
            this.summaryGroupBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox oilAndLubeGroupBox;
        private System.Windows.Forms.CheckBox lubeJobCheckBox;
        private System.Windows.Forms.CheckBox oilChangeCheckBox;
        private System.Windows.Forms.GroupBox miscGroupBox;
        private System.Windows.Forms.CheckBox tireRotationCheckBox;
        private System.Windows.Forms.CheckBox replaceMufflerCheckBox;
        private System.Windows.Forms.CheckBox inspectionCheckBox;
        private System.Windows.Forms.GroupBox flushesGroupBox;
        private System.Windows.Forms.CheckBox transFlushCheckBox;
        private System.Windows.Forms.CheckBox radFlushCheckBox;
        private System.Windows.Forms.GroupBox partsAndLaborGroupBox;
        private System.Windows.Forms.Label laborLabel;
        private System.Windows.Forms.Label partsLabel;
        private System.Windows.Forms.TextBox laborTextBox;
        private System.Windows.Forms.TextBox partsTextBox;
        private System.Windows.Forms.GroupBox summaryGroupBox;
        private System.Windows.Forms.Label totalFeesLabel;
        private System.Windows.Forms.Label taxLabel;
        private System.Windows.Forms.Label partsSummaryLabel;
        private System.Windows.Forms.Label serviceAndLaborLabel;
        private System.Windows.Forms.Button calculateButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.TextBox serviceAndLaborTextBox;
        private System.Windows.Forms.TextBox totalFeesTextBox;
        private System.Windows.Forms.TextBox taxOnPartsTextBox;
        private System.Windows.Forms.TextBox partsSumTextBox;
    }
}

