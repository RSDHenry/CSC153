﻿namespace Software_Sales
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.packagesBoughtTextBox = new System.Windows.Forms.TextBox();
            this.appliedDiscountLabel = new System.Windows.Forms.Label();
            this.displayTotalLabel = new System.Windows.Forms.Label();
            this.boughtPackagesLabel = new System.Windows.Forms.Label();
            this.discountTextLabel = new System.Windows.Forms.Label();
            this.totalTextLabel = new System.Windows.Forms.Label();
            this.resetButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.calculateButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // packagesBoughtTextBox
            // 
            this.packagesBoughtTextBox.Location = new System.Drawing.Point(220, 52);
            this.packagesBoughtTextBox.Name = "packagesBoughtTextBox";
            this.packagesBoughtTextBox.Size = new System.Drawing.Size(100, 20);
            this.packagesBoughtTextBox.TabIndex = 0;
            // 
            // appliedDiscountLabel
            // 
            this.appliedDiscountLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.appliedDiscountLabel.Location = new System.Drawing.Point(220, 81);
            this.appliedDiscountLabel.Name = "appliedDiscountLabel";
            this.appliedDiscountLabel.Size = new System.Drawing.Size(100, 20);
            this.appliedDiscountLabel.TabIndex = 1;
            this.appliedDiscountLabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // displayTotalLabel
            // 
            this.displayTotalLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.displayTotalLabel.Location = new System.Drawing.Point(220, 113);
            this.displayTotalLabel.Name = "displayTotalLabel";
            this.displayTotalLabel.Size = new System.Drawing.Size(100, 20);
            this.displayTotalLabel.TabIndex = 2;
            this.displayTotalLabel.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
            // 
            // boughtPackagesLabel
            // 
            this.boughtPackagesLabel.AutoSize = true;
            this.boughtPackagesLabel.Location = new System.Drawing.Point(5, 55);
            this.boughtPackagesLabel.Name = "boughtPackagesLabel";
            this.boughtPackagesLabel.Size = new System.Drawing.Size(209, 13);
            this.boughtPackagesLabel.TabIndex = 3;
            this.boughtPackagesLabel.Text = "Enter the number of packages purchased: ";
            // 
            // discountTextLabel
            // 
            this.discountTextLabel.AutoSize = true;
            this.discountTextLabel.Location = new System.Drawing.Point(121, 88);
            this.discountTextLabel.Name = "discountTextLabel";
            this.discountTextLabel.Size = new System.Drawing.Size(93, 13);
            this.discountTextLabel.TabIndex = 4;
            this.discountTextLabel.Text = "Applied Discount: ";
            // 
            // totalTextLabel
            // 
            this.totalTextLabel.AutoSize = true;
            this.totalTextLabel.Location = new System.Drawing.Point(177, 114);
            this.totalTextLabel.Name = "totalTextLabel";
            this.totalTextLabel.Size = new System.Drawing.Size(37, 13);
            this.totalTextLabel.TabIndex = 5;
            this.totalTextLabel.Text = "Total: ";
            this.totalTextLabel.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(122, 210);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 6;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(203, 210);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // calculateButton
            // 
            this.calculateButton.Location = new System.Drawing.Point(229, 147);
            this.calculateButton.Name = "calculateButton";
            this.calculateButton.Size = new System.Drawing.Size(75, 23);
            this.calculateButton.TabIndex = 8;
            this.calculateButton.Text = "Calculate";
            this.calculateButton.UseVisualStyleBackColor = true;
            this.calculateButton.Click += new System.EventHandler(this.calculateButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(366, 269);
            this.Controls.Add(this.calculateButton);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.totalTextLabel);
            this.Controls.Add(this.discountTextLabel);
            this.Controls.Add(this.boughtPackagesLabel);
            this.Controls.Add(this.displayTotalLabel);
            this.Controls.Add(this.appliedDiscountLabel);
            this.Controls.Add(this.packagesBoughtTextBox);
            this.Name = "Form1";
            this.Text = "Software Sales";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox packagesBoughtTextBox;
        private System.Windows.Forms.Label appliedDiscountLabel;
        private System.Windows.Forms.Label displayTotalLabel;
        private System.Windows.Forms.Label boughtPackagesLabel;
        private System.Windows.Forms.Label discountTextLabel;
        private System.Windows.Forms.Label totalTextLabel;
        private System.Windows.Forms.Button resetButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Button calculateButton;
    }
}

