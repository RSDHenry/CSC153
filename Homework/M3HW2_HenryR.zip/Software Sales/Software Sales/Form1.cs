﻿/**
* 6 MARCH 2018
* CSC 153
* Rashad Henry
* Program to calculate the total sales amount
* of software packages with quantity discounts
* applied when appropriate
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Sales
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                // Declare constant variable.
                const double RETAIL_PRICE = 99;

                // Declare local variables.
                int packagesPurchased = 0;
                double total = 0;
                double appliedDiscount = 0;
                double amountOfOrder = 0;
                double discountAmount = 0;

                // Take input string and convert to integer.
                packagesPurchased = int.Parse(packagesBoughtTextBox.Text);

                // If-else-if decision to display applied discounts.

                if (packagesPurchased < 10)
                    appliedDiscountLabel.Text = "None";
                else if (packagesPurchased >= 10 && packagesPurchased <= 19)
                    appliedDiscountLabel.Text = "20%";
                else if (packagesPurchased >= 20 && packagesPurchased <= 49)
                    appliedDiscountLabel.Text = "30%";
                else if (packagesPurchased >= 50 && packagesPurchased <= 99)
                    appliedDiscountLabel.Text = "40%";
                else if (packagesPurchased >= 100)
                    appliedDiscountLabel.Text = "50%";

                // If-else-if decision structure to determine discount to calculate.

                if (packagesPurchased < 10)
                    appliedDiscount = 0;
                else if (packagesPurchased >= 10 && packagesPurchased <= 19)
                    appliedDiscount = 0.20;
                else if (packagesPurchased >= 20 && packagesPurchased <= 49)
                    appliedDiscount = 0.30;
                else if (packagesPurchased >= 50 && packagesPurchased <= 99)
                    appliedDiscount = 0.40;
                else if (packagesPurchased >= 100)
                    appliedDiscount = 0.50;

                // Calculate the amount of the order, discount, and total.
                amountOfOrder = packagesPurchased * RETAIL_PRICE;
                discountAmount = amountOfOrder * appliedDiscount;
                total = amountOfOrder - discountAmount;

                // Display the total the user.
                displayTotalLabel.Text = total.ToString("c");
            }
            catch
            {
                // Display an error message.
                MessageBox.Show("Invalid data was entered. Please enter a number.");
            }
            } 

        private void resetButton_Click(object sender, EventArgs e)
        {
           // Clear the text and label boxes.
           packagesBoughtTextBox.Text = "";
           appliedDiscountLabel.Text = "";
           displayTotalLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form.
            this.Close();
        }
    }
}