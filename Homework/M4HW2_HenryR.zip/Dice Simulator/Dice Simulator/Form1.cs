﻿/**
* 25 March 2018
* CSC 153
* Rashad Henry
* This program generates a random roll of two dice.
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Dice_Simulator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollDiceButton_Click(object sender, EventArgs e)
        {
            // Added the dice images to the debug folder of the Bin folder of this project.

            // Set an dice object for random class.
            Random random = new Random();

            // Generate two random numbers in range 1 through 6 for Dice 1 and Dice 2.
            int randomDice1 = random.Next(1, 7);
            int randomDice2 = random.Next(1, 7);

            // To prevent the same random numbers for Dice 1 and Dice 2.
            // regenerate the random numbers only Dice 1 == Dice 2.
            while (randomDice1 == randomDice2)
            {
                randomDice1 = random.Next(1, 7);
                randomDice2 = random.Next(1, 7);
            }

            // Display the dice image in picture box.
            displayDice(randomDice1, picutreBoxDice1);
            displayDice(randomDice2, pictureBoxDice2);
        }
            // Create a displayDice method.
            private void displayDice (
                int randomDiceNum, PictureBox dicePicBox)
        {
            // Use a switch case to display the dice image.
            switch (randomDiceNum)
            {
                case 1:
                    dicePicBox.ImageLocation = "1Die.bmp";
                    break;
                case 2:
                    dicePicBox.ImageLocation = "2Die.bmp";
                    break;
                case 3:
                    dicePicBox.ImageLocation = "3Die.bmp";
                    break;
                case 4:
                    dicePicBox.ImageLocation = "4Die.bmp";
                    break;
                case 5:
                    dicePicBox.ImageLocation = "5Die.bmp";
                    break;
                case 6:
                    dicePicBox.ImageLocation = "6Die.bmp";
                    break;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the dice program.
            this.Close();
        }
    }
}
