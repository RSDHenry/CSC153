﻿namespace Dorm_and_Meal_Plan
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpDormsPlan = new System.Windows.Forms.GroupBox();
            this.rbUniversitySuites = new System.Windows.Forms.RadioButton();
            this.rbFarthingHall = new System.Windows.Forms.RadioButton();
            this.rbPikeHall = new System.Windows.Forms.RadioButton();
            this.rbAllenHall = new System.Windows.Forms.RadioButton();
            this.grpMealPlan = new System.Windows.Forms.GroupBox();
            this.rbUnlimitedMeals = new System.Windows.Forms.RadioButton();
            this.rb14Meals = new System.Windows.Forms.RadioButton();
            this.rb7Meals = new System.Windows.Forms.RadioButton();
            this.totalButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.grpDormsPlan.SuspendLayout();
            this.grpMealPlan.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpDormsPlan
            // 
            this.grpDormsPlan.Controls.Add(this.rbUniversitySuites);
            this.grpDormsPlan.Controls.Add(this.rbFarthingHall);
            this.grpDormsPlan.Controls.Add(this.rbPikeHall);
            this.grpDormsPlan.Controls.Add(this.rbAllenHall);
            this.grpDormsPlan.Location = new System.Drawing.Point(12, 12);
            this.grpDormsPlan.Name = "grpDormsPlan";
            this.grpDormsPlan.Size = new System.Drawing.Size(200, 126);
            this.grpDormsPlan.TabIndex = 0;
            this.grpDormsPlan.TabStop = false;
            this.grpDormsPlan.Text = "Choose a Dorm";
            // 
            // rbUniversitySuites
            // 
            this.rbUniversitySuites.AutoSize = true;
            this.rbUniversitySuites.Location = new System.Drawing.Point(57, 92);
            this.rbUniversitySuites.Name = "rbUniversitySuites";
            this.rbUniversitySuites.Size = new System.Drawing.Size(103, 17);
            this.rbUniversitySuites.TabIndex = 3;
            this.rbUniversitySuites.Text = "University Suites";
            this.rbUniversitySuites.UseVisualStyleBackColor = true;
            // 
            // rbFarthingHall
            // 
            this.rbFarthingHall.AutoSize = true;
            this.rbFarthingHall.Location = new System.Drawing.Point(57, 69);
            this.rbFarthingHall.Name = "rbFarthingHall";
            this.rbFarthingHall.Size = new System.Drawing.Size(84, 17);
            this.rbFarthingHall.TabIndex = 2;
            this.rbFarthingHall.Text = "Farthing Hall";
            this.rbFarthingHall.UseVisualStyleBackColor = true;
            // 
            // rbPikeHall
            // 
            this.rbPikeHall.AutoSize = true;
            this.rbPikeHall.Location = new System.Drawing.Point(57, 46);
            this.rbPikeHall.Name = "rbPikeHall";
            this.rbPikeHall.Size = new System.Drawing.Size(67, 17);
            this.rbPikeHall.TabIndex = 1;
            this.rbPikeHall.Text = "Pike Hall";
            this.rbPikeHall.UseVisualStyleBackColor = true;
            // 
            // rbAllenHall
            // 
            this.rbAllenHall.AutoSize = true;
            this.rbAllenHall.Checked = true;
            this.rbAllenHall.Location = new System.Drawing.Point(57, 23);
            this.rbAllenHall.Name = "rbAllenHall";
            this.rbAllenHall.Size = new System.Drawing.Size(69, 17);
            this.rbAllenHall.TabIndex = 0;
            this.rbAllenHall.TabStop = true;
            this.rbAllenHall.Text = "Allen Hall";
            this.rbAllenHall.UseVisualStyleBackColor = true;
            // 
            // grpMealPlan
            // 
            this.grpMealPlan.Controls.Add(this.rbUnlimitedMeals);
            this.grpMealPlan.Controls.Add(this.rb14Meals);
            this.grpMealPlan.Controls.Add(this.rb7Meals);
            this.grpMealPlan.Location = new System.Drawing.Point(218, 12);
            this.grpMealPlan.Name = "grpMealPlan";
            this.grpMealPlan.Size = new System.Drawing.Size(200, 126);
            this.grpMealPlan.TabIndex = 1;
            this.grpMealPlan.TabStop = false;
            this.grpMealPlan.Text = "Choose a Meal Plan";
            // 
            // rbUnlimitedMeals
            // 
            this.rbUnlimitedMeals.AutoSize = true;
            this.rbUnlimitedMeals.Location = new System.Drawing.Point(57, 69);
            this.rbUnlimitedMeals.Name = "rbUnlimitedMeals";
            this.rbUnlimitedMeals.Size = new System.Drawing.Size(98, 17);
            this.rbUnlimitedMeals.TabIndex = 2;
            this.rbUnlimitedMeals.Text = "Unlimited meals";
            this.rbUnlimitedMeals.UseVisualStyleBackColor = true;
            // 
            // rb14Meals
            // 
            this.rb14Meals.AutoSize = true;
            this.rb14Meals.Location = new System.Drawing.Point(57, 46);
            this.rb14Meals.Name = "rb14Meals";
            this.rb14Meals.Size = new System.Drawing.Size(114, 17);
            this.rb14Meals.TabIndex = 1;
            this.rb14Meals.Text = "14 meals per week";
            this.rb14Meals.UseVisualStyleBackColor = true;
            // 
            // rb7Meals
            // 
            this.rb7Meals.AutoSize = true;
            this.rb7Meals.Checked = true;
            this.rb7Meals.Location = new System.Drawing.Point(57, 23);
            this.rb7Meals.Name = "rb7Meals";
            this.rb7Meals.Size = new System.Drawing.Size(108, 17);
            this.rb7Meals.TabIndex = 0;
            this.rb7Meals.TabStop = true;
            this.rb7Meals.Text = "7 meals per week";
            this.rb7Meals.UseVisualStyleBackColor = true;
            // 
            // totalButton
            // 
            this.totalButton.Location = new System.Drawing.Point(121, 150);
            this.totalButton.Name = "totalButton";
            this.totalButton.Size = new System.Drawing.Size(91, 36);
            this.totalButton.TabIndex = 2;
            this.totalButton.Text = "Display Total";
            this.totalButton.UseVisualStyleBackColor = true;
            this.totalButton.Click += new System.EventHandler(this.btnCalc_Click);
            // 
            // exitButton
            // 
            this.exitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitButton.Location = new System.Drawing.Point(218, 150);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(91, 36);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // MainForm
            // 
            this.AcceptButton = this.totalButton;
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitButton;
            this.ClientSize = new System.Drawing.Size(431, 221);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.totalButton);
            this.Controls.Add(this.grpMealPlan);
            this.Controls.Add(this.grpDormsPlan);
            this.Name = "MainForm";
            this.Text = "Dorm and Meal Plan Calculator";
            this.grpDormsPlan.ResumeLayout(false);
            this.grpDormsPlan.PerformLayout();
            this.grpMealPlan.ResumeLayout(false);
            this.grpMealPlan.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpDormsPlan;
        private System.Windows.Forms.RadioButton rbUniversitySuites;
        private System.Windows.Forms.RadioButton rbFarthingHall;
        private System.Windows.Forms.RadioButton rbPikeHall;
        private System.Windows.Forms.RadioButton rbAllenHall;
        private System.Windows.Forms.GroupBox grpMealPlan;
        private System.Windows.Forms.RadioButton rbUnlimitedMeals;
        private System.Windows.Forms.RadioButton rb14Meals;
        private System.Windows.Forms.RadioButton rb7Meals;
        private System.Windows.Forms.Button totalButton;
        private System.Windows.Forms.Button exitButton;
    }
}

