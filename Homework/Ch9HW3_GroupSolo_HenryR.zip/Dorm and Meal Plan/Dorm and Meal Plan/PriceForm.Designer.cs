﻿namespace Dorm_and_Meal_Plan
{
    partial class PriceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dormPriceHeaderLabel = new System.Windows.Forms.Label();
            this.mealPlanPriceHeaderLabel = new System.Windows.Forms.Label();
            this.totalPriceHeaderLabel = new System.Windows.Forms.Label();
            this.dormPriceLabel = new System.Windows.Forms.Label();
            this.mealPlanPriceLabel = new System.Windows.Forms.Label();
            this.totalPriceLabel = new System.Windows.Forms.Label();
            this.planPricesExitButton = new System.Windows.Forms.Button();
            this.dormPlanLabel = new System.Windows.Forms.Label();
            this.dormHeaderLabel = new System.Windows.Forms.Label();
            this.mealPlanLabel = new System.Windows.Forms.Label();
            this.mealPlanHeaderLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // dormPriceHeaderLabel
            // 
            this.dormPriceHeaderLabel.AutoSize = true;
            this.dormPriceHeaderLabel.Location = new System.Drawing.Point(58, 81);
            this.dormPriceHeaderLabel.Name = "dormPriceHeaderLabel";
            this.dormPriceHeaderLabel.Size = new System.Drawing.Size(62, 13);
            this.dormPriceHeaderLabel.TabIndex = 0;
            this.dormPriceHeaderLabel.Text = "Dorm Price:";
            // 
            // mealPlanPriceHeaderLabel
            // 
            this.mealPlanPriceHeaderLabel.AutoSize = true;
            this.mealPlanPriceHeaderLabel.Location = new System.Drawing.Point(36, 109);
            this.mealPlanPriceHeaderLabel.Name = "mealPlanPriceHeaderLabel";
            this.mealPlanPriceHeaderLabel.Size = new System.Drawing.Size(84, 13);
            this.mealPlanPriceHeaderLabel.TabIndex = 1;
            this.mealPlanPriceHeaderLabel.Text = "Meal Plan Price:";
            // 
            // totalPriceHeaderLabel
            // 
            this.totalPriceHeaderLabel.AutoSize = true;
            this.totalPriceHeaderLabel.Location = new System.Drawing.Point(58, 137);
            this.totalPriceHeaderLabel.Name = "totalPriceHeaderLabel";
            this.totalPriceHeaderLabel.Size = new System.Drawing.Size(61, 13);
            this.totalPriceHeaderLabel.TabIndex = 2;
            this.totalPriceHeaderLabel.Text = "Total Price:";
            // 
            // dormPriceLabel
            // 
            this.dormPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dormPriceLabel.Location = new System.Drawing.Point(125, 76);
            this.dormPriceLabel.Name = "dormPriceLabel";
            this.dormPriceLabel.Size = new System.Drawing.Size(121, 23);
            this.dormPriceLabel.TabIndex = 3;
            this.dormPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mealPlanPriceLabel
            // 
            this.mealPlanPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mealPlanPriceLabel.Location = new System.Drawing.Point(125, 104);
            this.mealPlanPriceLabel.Name = "mealPlanPriceLabel";
            this.mealPlanPriceLabel.Size = new System.Drawing.Size(121, 23);
            this.mealPlanPriceLabel.TabIndex = 4;
            this.mealPlanPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // totalPriceLabel
            // 
            this.totalPriceLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.totalPriceLabel.Location = new System.Drawing.Point(125, 132);
            this.totalPriceLabel.Name = "totalPriceLabel";
            this.totalPriceLabel.Size = new System.Drawing.Size(121, 23);
            this.totalPriceLabel.TabIndex = 5;
            this.totalPriceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // planPricesExitButton
            // 
            this.planPricesExitButton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.planPricesExitButton.Location = new System.Drawing.Point(125, 174);
            this.planPricesExitButton.Name = "planPricesExitButton";
            this.planPricesExitButton.Size = new System.Drawing.Size(91, 36);
            this.planPricesExitButton.TabIndex = 6;
            this.planPricesExitButton.Text = "Exit";
            this.planPricesExitButton.UseVisualStyleBackColor = true;
            this.planPricesExitButton.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // dormPlanLabel
            // 
            this.dormPlanLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dormPlanLabel.Location = new System.Drawing.Point(125, 9);
            this.dormPlanLabel.Name = "dormPlanLabel";
            this.dormPlanLabel.Size = new System.Drawing.Size(121, 23);
            this.dormPlanLabel.TabIndex = 8;
            this.dormPlanLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // dormHeaderLabel
            // 
            this.dormHeaderLabel.AutoSize = true;
            this.dormHeaderLabel.Location = new System.Drawing.Point(84, 14);
            this.dormHeaderLabel.Name = "dormHeaderLabel";
            this.dormHeaderLabel.Size = new System.Drawing.Size(35, 13);
            this.dormHeaderLabel.TabIndex = 7;
            this.dormHeaderLabel.Text = "Dorm:";
            // 
            // mealPlanLabel
            // 
            this.mealPlanLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.mealPlanLabel.Location = new System.Drawing.Point(125, 37);
            this.mealPlanLabel.Name = "mealPlanLabel";
            this.mealPlanLabel.Size = new System.Drawing.Size(121, 23);
            this.mealPlanLabel.TabIndex = 10;
            this.mealPlanLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // mealPlanHeaderLabel
            // 
            this.mealPlanHeaderLabel.AutoSize = true;
            this.mealPlanHeaderLabel.Location = new System.Drawing.Point(62, 42);
            this.mealPlanHeaderLabel.Name = "mealPlanHeaderLabel";
            this.mealPlanHeaderLabel.Size = new System.Drawing.Size(57, 13);
            this.mealPlanHeaderLabel.TabIndex = 9;
            this.mealPlanHeaderLabel.Text = "Meal Plan:";
            // 
            // PriceForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.planPricesExitButton;
            this.ClientSize = new System.Drawing.Size(316, 218);
            this.Controls.Add(this.mealPlanLabel);
            this.Controls.Add(this.mealPlanHeaderLabel);
            this.Controls.Add(this.dormPlanLabel);
            this.Controls.Add(this.dormHeaderLabel);
            this.Controls.Add(this.planPricesExitButton);
            this.Controls.Add(this.totalPriceLabel);
            this.Controls.Add(this.mealPlanPriceLabel);
            this.Controls.Add(this.dormPriceLabel);
            this.Controls.Add(this.totalPriceHeaderLabel);
            this.Controls.Add(this.mealPlanPriceHeaderLabel);
            this.Controls.Add(this.dormPriceHeaderLabel);
            this.Name = "PriceForm";
            this.Text = "Plan Prices";
            this.Load += new System.EventHandler(this.PriceForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label dormPriceHeaderLabel;
        private System.Windows.Forms.Label mealPlanPriceHeaderLabel;
        private System.Windows.Forms.Label totalPriceHeaderLabel;
        private System.Windows.Forms.Label dormPriceLabel;
        private System.Windows.Forms.Label mealPlanPriceLabel;
        private System.Windows.Forms.Label totalPriceLabel;
        private System.Windows.Forms.Button planPricesExitButton;
        private System.Windows.Forms.Label dormPlanLabel;
        private System.Windows.Forms.Label dormHeaderLabel;
        private System.Windows.Forms.Label mealPlanLabel;
        private System.Windows.Forms.Label mealPlanHeaderLabel;
    }
}